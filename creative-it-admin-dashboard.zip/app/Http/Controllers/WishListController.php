<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\WishList;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class WishListController extends Controller


{

    /* Add To WIshList  */

    public function addToWishList($id)
    {

        // $addedWishlists = Product::where('id',$id)->get();
        //  dd($addedWishlists->id);
        if(Auth::check()){
            if(WishList::where('user_id',auth()->user()->id)->where('product_id',$id)->exists()){

                WishList::where('user_id',auth()->user()->id)->where('product_id',$id)->first()->increment('quantity');
                WishList::where('user_id',auth()->user()->id)->where('product_id',$id)->first()->increment('price');
            }
            else{

            $productPrice = Product::find($id)->first();
             $wishlistQuantity = WishList::where('product_id',$id)->first();
           // dd($productPrice);
            WishList::create([
            'product_id'=>$id,
            'user_id'=> auth()->user()->id,
            'quantity'=>1,
            'price'=>$productPrice->price * $wishlistQuantity->quantity,

        ]);

        return back();

    }


    }else{

        return back();
    }



    }

    public function allWishList()
    {

        $allWishlists = WishList::has('products')->where('user_id',auth()->user()->id)->get();
    }
}
