<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CouponController extends Controller
{
    public function storeOrUpdate($para)
    {
        $para->validate([

            'coupon_name'=>'required|unique:coupons,coupon_name,',
            'coupon_discount'=>'required',
            'coupon_validity'=>'required',
        ]);
    }

    public function addCoupon()
    {


        return view('backend.coupon.coupon');
    }

    public function storeCoupon(Request $request)
    {

    }
}
