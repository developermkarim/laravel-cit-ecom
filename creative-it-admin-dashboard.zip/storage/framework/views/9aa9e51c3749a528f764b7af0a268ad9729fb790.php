

<?php $__env->startSection('frontend-content'); ?>
   

   <div class="wishlist-area pt-60 pb-60">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <form action="#">
                    <div class="table-content table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th class="li-product-remove">remove</th>
                                    <th class="li-product-thumbnail">images</th>
                                    <th class="cart-product-name">Product</th>
                                    <th class="li-product-price">Unit Price</th>
                                    <th class="text-dark">Quantity</th>
                                    <th class="li-product-stock-status">Stock Status</th>
                                    <th class="li-product-add-cart">add to cart</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $total = 0;
                                ?>
                                <?php $__currentLoopData = $allWishlists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wishlist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $total+= ($wishlist->products->discount_price ?? $wishlist->products->price) * $wishlist->quantity;
                                    ?> 
                               
                                <tr>
                                    <td class=""><a href="<?php echo e(route('user.wishlist.remove',$wishlist->id)); ?>">❌</a></td>
                                    <td class="li-product-thumbnail"><a href="#"><img src="<?php echo e($wishlist->products->thumbnail_uri); ?>" alt="<?php echo e($wishlist->products->title); ?>" width="100" height="100"></a></td>
                                    <td class="li-product-name"><a href="#"><?php echo e($wishlist->products->title); ?></a></td>
                                    
                                    <td class="li-product-price"><span class="amount">$<?php echo e(number_format($total,2)); ?></span></td>

                                    <td class="li-product-price"><span class="amount"><?php echo e($wishlist->quantity); ?></span></td>
                                    
                                    <td class="li-product-stock-status"><span class="in-stock">in stock </span></td>
                                    <td class="li-product-add-cart"><a href="<?php echo e(route('user.product.cart',$wishlist->products->id)); ?>">add to cart</a></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontendapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\SUNDISK-PENDRIVE\WDPF-LARAVEL\creative-it-admin-dashboard\resources\views/frontend/wishlist/wishlist.blade.php ENDPATH**/ ?>