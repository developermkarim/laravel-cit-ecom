<?php $__env->startSection('content'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<h1 class="text-3xl font-bold underline">
  <h2 class="text-center">
    <?php if (isset($component)) { $__componentOriginalf6d1e1ab7a8df2de5d0bdc28df8775f180a35b0c = $component; } ?>
<?php $component = $__env->getContainer()->make(Mckenziearts\Notify\NotifyComponent::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('notify-messages'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Mckenziearts\Notify\NotifyComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf6d1e1ab7a8df2de5d0bdc28df8775f180a35b0c)): ?>
<?php $component = $__componentOriginalf6d1e1ab7a8df2de5d0bdc28df8775f180a35b0c; ?>
<?php unset($__componentOriginalf6d1e1ab7a8df2de5d0bdc28df8775f180a35b0c); ?>
<?php endif; ?>
  </h2>
  District Management
</h1>
<div class="row">

   <div class="col-lg-8">


      <table class="table table-responsive">
         <thead>
           <tr>
             <th scope="col">S/L</th>
             <th scope="col">Division</th>
             <th scope="col">District</th>
             <th scope="col">State</th>

             <th scope="col">Action</th>
           </tr>
         </thead>
         <tbody>
          <?php $__empty_1 = true; $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>


           <tr>
            <td><?php echo e(++$key); ?></td>

            <td><?php echo e($item->division->division_name); ?></td>

             <td><?php echo e($item->district ? $item->district->district_name :'No district'); ?></td>
             <td><?php echo e($item->state_name); ?></td>
              

             <td><a  class="btn btn-primary" class="btn" href="<?php echo e(url('shipping/district/edit',$item->id)); ?>"><i class="fas fa-edit"></i></a>

               &nbsp;

               <a href="<?php echo e(url('shipping/district/delete', $item->id)); ?>" id="deleteBtn" class="btn btn-danger"> <i class="fas fa-trash-alt"></i></a>

               




              </td>



           </tr>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <tr>
                <td>
                  No Data Found
                </td>
              </tr>
           <?php endif; ?>
         </tbody>
       </table>



   </div>

   <div class="col-lg-4">
      <div class="">

        <?php if(!isset($editedstate)): ?>



         <form action="<?php echo e(route('ship.state.store')); ?>" method="POST" class="card-body">
          <?php echo csrf_field(); ?>

            <h4>Add New State</h4>

       <select name="division_id" id="division_id" class="form-select" aria-label="Default select example">
        <option selected>Select one Division</option>
        <?php $__currentLoopData = $divisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $division): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($division->id); ?>"><?php echo e($division->division_name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </select>

       <select name="district_id" id="district_id" class="form-select" aria-label="Default select example">
        <option selected>Select one District</option>
      
       </select>

            <input type="text" name="state_name"  id="state_name" placeholder= "wriite State name"  class="form-control">
            <?php $__errorArgs = ['district_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-theme-6"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

           <button type="submit" class="w-full btn btn-primary">Upload State</button>
         </form>

         <?php else: ?>


         <form action="<?php echo e(route('ship.district.update',$editeddistrict->id)); ?>"  method="POST" class="card-body">
            <?php echo csrf_field(); ?>

        <?php echo method_field('PUT'); ?>

              <h4>Update State</h4>

              
              <input type="hidden" id="" name="update_id" value="<?php echo e($editeddistrict->id); ?>">

              <select name="division_id" id="division_id" class="form-select" aria-label="Default select example">
                <option selected>Select one Division</option>
                <?php $__currentLoopData = $divisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $division): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php echo e($division->id == $editeddistrict->division_id? 'selected':''); ?> value="<?php echo e($division->id); ?>"><?php echo e($division->division_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </select>

              <select name="district_id" id="district_id" class="form-select" aria-label="Default select example">
                <option selected>Select one District</option>
              
               </select>

            <input type="text" name="state_name"  value="<?php echo e($editeddistrict->state_name); ?>" id="state_name" placeholder="Divison Name" class="form-control">
            <?php $__errorArgs = ['district_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-theme-6"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

             <button type="submit" class="w-full btn btn-primary">Update State</button>
           </form>


         <?php endif; ?>
       </div>
   </div>

</div>



<?php $__env->startPush('customJs'); ?>

    <script>
      let title = $('input[name="title"]');
      let slug = $('input[name="slug"]');
      title.keyup(function(){

        let titleValue = $(this).val().toLowerCase().split(' ').join('-');
        slug.val(titleValue);

      });


      /* Delete Button With Sweet Alert */

$(function(){


  $(document).on('click','#deleteBtn', function(e){
    e.preventDefault();
    var link = $(this).attr('href');
  Swal.fire({
  title: 'Are you sure?',
  text: "You won't be able to revert this!",/* F */
  icon: 'warning',
  showCancelButton: true,
  confirmButtonColor: '#1C3FAA',
  cancelButtonColor: '#d33',
  confirmButtonText: 'Yes, delete it!'
}).then((result) => {
  if (result.isConfirmed) {

    window.location.href = link;
    swal.fire( 'Deleted!',
                        'Your file has been deleted.',
                        'success')

  }
})
 })
})
    </script>

    <script>
        $(function(){
            $(document).on('change','#division_id',function(){
                var division_id = $(this).val();

                $.ajax({
                    url:"<?php echo e(route('ship.get.district')); ?>",
                    type:'get',
                    data:{division_id:division_id},
                    success:(response)=>{
                        var option = "<option value=''> Select District</option>";

                        $.each(response,function(key,value){

                            option+= `<option value="${value.id}">${value.district_name}</option>`

                        })

                        $('#district_id').html(option)
                    }
                })
            })
        })
    </script>
<?php $__env->stopPush(); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backendapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\CREATIVE-IT-LARAVEL\creative-it-admin-dashboard\resources\views/backend/shippingArea/shippState.blade.php ENDPATH**/ ?>