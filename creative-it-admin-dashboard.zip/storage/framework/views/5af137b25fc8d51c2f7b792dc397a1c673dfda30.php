
<!doctype html>
<html>

<!-- shopping-cart31:32-->
<head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Shopping Cart || limupa - Digital Products Store eCommerce Bootstrap 4 Template</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Favicon -->
        <link rel="shortcut icon" type="image/x-icon" href="images/favicon.png">
        <!-- Material Design Iconic Font-V2.2.0 -->
        <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/material-design-iconic-font.min.css')); ?>">
        <!-- Font Awesome -->
        <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/font-awesome.min.css')); ?>">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.4/toastr.css"/>
        <!-- Font Awesome Stars-->
        <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/fontawesome-stars.css')); ?>">
        <!-- Meanmenu CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/meanmenu.css')); ?>">
        <!-- owl carousel CSS -->
        <link rel="stylesheet" href="
        <?php echo e(asset('frontend/assets/css/owl.carousel.min.css')); ?>">
        <!-- Slick Carousel CSS -->

        <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/slick.css')); ?>">
        <!-- Animate CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/animate.css')); ?>">
        <!-- Jquery-ui CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/jquery-ui.min.css')); ?>">
        <!-- Venobox CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/venobox.css')); ?>">
        <!-- Nice Select CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/nice-select.css')); ?>">
        <!-- Magnific Popup CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/magnific-popup.css')); ?>">
        
        <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/bootstrap.min.css')); ?>">
        <!-- Helper CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/helper.css')); ?>">
        <!-- Main Style CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/style.css')); ?>">

         
         <link rel="stylesheet" href="<?php echo e(asset('frontend/asset/css/price_range_style.css')); ?>">
          
          <script  src="<?php echo e(asset('frontend/asset/js/price_range_script.js')); ?>"></script>
        <!-- Responsive CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/responsive.css')); ?>">
        <!-- Modernizr js -->
        <script src="<?php echo e(asset('frontend/assets/js/vendor/modernizr-2.8.3.min.js')); ?>"></script>
        <script src="https://kit.fontawesome.com/92d6c198cd.js" crossorigin="anonymous"></script>
        <?php echo $__env->yieldContent('customStyle'); ?>
    </head>
    <body>


          <!--[if lt IE 8]>
		<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
	<![endif]-->
        <!-- Begin Body Wrapper -->
        <div class="body-wrapper">
            <!-- Begin Header Area -->
            <header class="li-header-4">
                <!-- Begin Header Top Area -->
                <div class="header-top">
                    <div class="container">
                        <div class="row">
                            <!-- Begin Header Top Left Area -->
                            <div class="col-lg-3 col-md-4">
                                <div class="header-top-left">
                                    <ul class="phone-wrap">
                                        <li><span>Telephone Enquiry:</span><a href="#">(+123) 123 321 345</a></li>
                                    </ul>
                                </div>
                            </div>
                            <!-- Header Top Left Area End Here -->
                            <!-- Begin Header Top Right Area -->
                            <div class="col-lg-9 col-md-8">
                                <div class="header-top-right">
                                    <ul class="ht-menu">
                                        <!-- Begin Setting Area -->
                                        <li>
                                            <div class="ht-setting-trigger"><span>Setting</span></div>
                                            <div class="setting ht-setting">
                                                <ul class="ht-setting-list">

                                                    <?php if(auth()->guard()->check()): ?>
                                                    <li><a href="login-register.html">My Account</a></li>

                                                    <li><a href="checkout.html">Checkout</a></li>
                                                    <li> <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                                        onclick="event.preventDefault();
                                                                     document.getElementById('logout-form').submit();">
                                                        <?php echo e(__('Logout')); ?>

                                                    </a>

                                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                                        <?php echo csrf_field(); ?>
                                                    </form>
                                                </li>
                                                    <?php endif; ?>

                                                    <?php if(auth()->guard()->guest()): ?>
                                                    <li><a href="<?php echo e(route('user.login')); ?>">Sign In</a></li>

                                                    <li><a href="<?php echo e(route('user.register')); ?>">Sign Up</a></li>

                                              <?php endif; ?>

                                                </ul>
                                            </div>
                                        </li>
                                        <!-- Setting Area End Here -->
                                        <!-- Begin Currency Area -->
                                        <li>
                                            <span class="currency-selector-wrapper">Currency :</span>
                                            <div class="ht-currency-trigger"><span>USD $</span></div>
                                            <div class="currency ht-currency">
                                                <ul class="ht-setting-list">
                                                    <li><a href="#">EUR €</a></li>
                                                    <li class="active"><a href="#">USD $</a></li>
                                                </ul>
                                            </div>
                                        </li>
                                        <!-- Currency Area End Here -->
                                        <!-- Begin Language Area -->
                                        <li>
                                            <span class="language-selector-wrapper">Language :</span>
                                            <div class="ht-language-trigger"><span>English</span></div>
                                            <div class="language ht-language">
                                                <ul class="ht-setting-list">
                                                    <li class="active"><a href="#"><img src="images/menu/flag-icon/1.jpg" alt="">English</a></li>
                                                    <li><a href="#"><img src="images/menu/flag-icon/2.jpg" alt="">Français</a></li>
                                                </ul>
                                            </div>
                                        </li>
                                        <!-- Language Area End Here -->
                                    </ul>
                                </div>
                            </div>
                            <!-- Header Top Right Area End Here -->
                        </div>
                    </div>
                </div>
                <!-- Header Top Area End Here -->
                <!-- Begin Header Middle Area -->
                <div class="header-middle pl-sm-0 pr-sm-0 pl-xs-0 pr-xs-0">
                    <div class="container">
                        <div class="row">
                            <!-- Begin Header Logo Area -->
                            <div class="col-lg-3">
                                <div class="logo pb-sm-30 pb-xs-30">
                                    <a href="index.html">
                                        <img src="images/menu/logo/2.jpg" alt="">
                                    </a>
                                </div>
                            </div>
                            <!-- Header Logo Area End Here -->
                            <!-- Begin Header Middle Right Area -->
                            <div class="col-lg-9 pl-0 ml-sm-15 ml-xs-15">
                                <!-- Begin Header Middle Searchbox Area -->
                                <form action="#" class="hm-searchbox" style="position: relative">
                                    <select class="nice-select select-search-category">
                                        <option value="0">All</option>
                                        <option value="34">- - - -  Headphones</option>
                                        <option value="35">- - - -  Video Games</option>
                                        <option value="36">- - - -  Wireless Speakers</option>
                                        <option value="19">- - - -  Electronics</option>



                                        <option value="65">- - - -  Tops</option>

                                    </select>
                                    <input id="search" type="text" placeholder="Enter your search key ...">
                                    <button id="search-btn" class="li-btn" type="submit"><i class="fa fa-search"></i></button>
                                    <div style="position: absolute; margin-left: 197px;
                                    margin-top: 41px;color:white">
                                        <ul style="background: #f6f7ec;padding:10px" id="ul-list">

                                        </ul>
                                    </div>
                                </form>


                                <!-- Header Middle Searchbox Area End Here -->
                                <!-- Begin Header Middle Right Area -->
                                <div class="header-middle-right">
                                    <ul class="hm-menu">
                                        <!-- Begin Header Middle Wishlist Area -->
                                        <li class="hm-wishlist">
                                            <a href="<?php echo e(route('user.show.wishlist')); ?>">
                                                <span class="cart-item-count wishlist-item-count"><?php echo e($wishListCount); ?></span>
                                                <i class="fa fa-heart-o"></i>
                                            </a>
                                        </li>
                                        
                                        <li class="hm-wishlist">
                                            <a href="<?php echo e(route('user.show.wishlist')); ?>">
                                                <span class="cart-item-count wishlist-item-count"><?php echo e($wishListCount); ?></span>
                                                <i class="fa fa-heart-o"></i>
                                            </a>
                                        </li>
                                        <!-- Header Middle Wishlist Area End Here -->
                                        <!-- Begin Header Mini Cart Area -->
                                        <li class="hm-minicart">
                                            <div class="hm-minicart-trigger">


                                                <?php
                                                $subToal = 0;
                                             ?>
                                            <?php if(isset($allcart)): ?>
                                           <?php $__currentLoopData = $allcart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                           <?php
                                               $subToal+= $cart->products->price * $cart->quantity;

                                           ?>
                                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                <?php endif; ?>
                                                <span class="item-icon"></span>
                                                <span class="item-text">৳<?php echo e(number_format($subToal,0)); ?>

                                                    <span class="cart-item-count"><?php echo e($cartCount); ?></span>
                                                </span>
                                            </div>
                                            <span></span>
                                            <div class="minicart">
                                                <ul class="minicart-product-list">
                                                    <?php
                                                    $subToal = 0;
                                                   $deliveryCharge=0;
                                                 ?>
                                                <?php if(isset($allcart)): ?>
                                               <?php $__currentLoopData = $allcart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                               <?php
                                                   $subToal+= $cart->products->price * $cart->quantity;
                                                   $deliveryCharge+= $cart->quantity * 50;
                                               ?>
                                                    <li>
                                                        <a href="single-product.html" class="minicart-product-image">
                                                            <img src="<?php echo e($cart->products->thumbnail_uri); ?>" alt="cart products">
                                                        </a>
                                                        <div class="minicart-product-details">
                                                            <h6><a href="single-product.html"><?php echo e($cart->products->name); ?></a></h6>
                                                            <span><?php echo e($cart->products->price); ?> x <?php echo e($cart->quantity); ?></span>
                                                        </div>

                                                       <a href="<?php echo e(url('cart/remove',$cart->id)); ?>">
                                                        <button class="close">
                                                            <i class="fa fa-close"></i>
                                                        </button>
                                                    </a>
                                                    </li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                <?php endif; ?>
                                                </ul>
                                                <p class="minicart-total">SUBTOTAL: <span>£<?php echo e($subToal); ?></span> ৳</p>
                                                <div class="minicart-button">
                                                    <a href="<?php echo e(url('user/cartList/')); ?>" class="li-button li-button-dark li-button-fullwidth li-button-sm">
                                                        <span>View Full Cart</span>
                                                    </a>
                                                    <a href="<?php echo e(route('cart.checkout.form')); ?>" class="li-button li-button-fullwidth li-button-sm">
                                                        <span>Checkout</span>
                                                    </a>
                                                </div>
                                            </div>
                                        </li>
                                        <!-- Header Mini Cart Area End Here -->
                                    </ul>
                                </div>
                                <!-- Header Middle Right Area End Here -->
                            </div>
                            <!-- Header Middle Right Area End Here -->
                        </div>
                    </div>
                </div>
                <!-- Header Middle Area End Here -->
                <!-- Begin Header Bottom Area -->
                <div class="header-bottom header-sticky stick d-none d-lg-block d-xl-block">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12">
                               <!-- Begin Header Bottom Menu Area -->
                               <div class="hb-menu">
                                   <nav >
                                       <ul style="margin-left: 554px">
                                        <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                                           <li class="megamenu-static-holder"><a href="index.html">Pages</a>

                                           </li>
                                           <li><a href="about-us.html">About Us</a></li>
                                           <li><a href="contact.html">Contact</a></li>
                                           <li><a href="shop-left-sidebar.html">Smartwatch</a></li>
                                           <li><a href="<?php echo e(route('product.shopFilter')); ?>">Shop</a></li>
                                       </ul>
                                   </nav>
                               </div>
                               <!-- Header Bottom Menu Area End Here -->
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Header Bottom Area End Here -->
                <!-- Begin Mobile Menu Area -->
                <div class="mobile-menu-area mobile-menu-area-4 d-lg-none d-xl-none col-12">
                    <div class="container">
                        <div class="row">
                            <div class="mobile-menu">
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Mobile Menu Area End Here -->
            </header>
            <!-- Header Area End Here -->
            <!-- Begin Slider With Banner Area -->

            

            <!-- Slider With Banner Area End Here -->
            <!-- Begin Static Top Area -->
           
            <!-- Static Top Area End Here -->
            <!-- product-area start -->
          
            <!-- product-area end -->
            <!-- Begin Li's Static Banner Area -->

            <!-- Li's Static Banner Area End Here -->
            <!-- Begin Li's Laptop Product Area -->
           
            <!-- Li's Laptop Product Area End Here -->
            <!-- Begin Li's TV & Audio Product Area -->
           
            <!-- Li's TV & Audio Product Area End Here -->
            <!-- Begin Li's Static Home Area -->
           
            <!-- Li's Static Home Area End Here -->
            <!-- Begin Group Featured Product Area -->
          
            <!-- Group Featured Product Area End Here -->
            <!-- Begin Footer Area -->

             <?php echo $__env->yieldContent('frontend-content'); ?>

             <?php echo $__env->yieldContent('cart-content'); ?>

            <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Footer Area End Here -->
            <!-- Begin Quick View | Modal Area -->

            <!-- Quick View | Modal Area End Here -->
        </div>
        <!-- Body Wrapper End Here -->

             

        <!-- jQuery-V1.12.4 -->
        <script src="<?php echo e(asset('frontend/assets/js/vendor/jquery-1.12.4.min.js')); ?>"></script>
        <!-- Popper js  -->
        
        <script src="<?php echo e(asset('frontend/assets/js/vendor/popper.min.js')); ?>"></script>
        <!-- Bootstrap V4.1.3 Fremwork js -->
        <script src="<?php echo e(asset('frontend/assets/js/bootstrap.min.js')); ?>"></script>
        <!-- Ajax Mail js -->
        <script src="<?php echo e(asset('frontend/assets/js/ajax-mail.js')); ?>"></script>
        <!-- Meanmenu js -->
        <script src="<?php echo e(asset('frontend/assets/js/jquery.meanmenu.min.js')); ?>"></script>
        <!-- Wow.min js -->
        <script src="<?php echo e(asset('frontend/assets/js/wow.min.js')); ?>"></script>
        <!-- Slick Carousel js -->
        <script src="<?php echo e(asset('frontend/assets/js/slick.min.js')); ?>"></script>
        <!-- Owl Carousel-2 js -->
        <script src="<?php echo e(asset('frontend/assets/js/owl.carousel.min.js')); ?>"></script>
        <!-- Magnific popup js -->
        <script src="<?php echo e(asset('frontend/assets/js/jquery.magnific-popup.min.js')); ?>"></script>
        <!-- Isotope js -->
        <script src="<?php echo e(asset('frontend/assets/js/isotope.pkgd.min.js')); ?>"></script>
        <!-- Imagesloaded js -->
        <script src="<?php echo e(asset('frontend/assets/js/imagesloaded.pkgd.min.js')); ?>"></script>
        <!-- Mixitup js -->
        <script src="<?php echo e(asset('frontend/assets/js/jquery.mixitup.min.js"')); ?>"></script>
        <!-- Countdown -->
        <script src="<?php echo e(asset('frontend/assets/js/jquery.countdown.min.js')); ?>"></script>
        <!-- Counterup -->
        <script src="<?php echo e(asset('frontend/assets/js/jquery.counterup.min.js')); ?>"></script>
        <!-- Waypoints -->
        <script src="<?php echo e(asset('frontend/assets/js/waypoints.min.js')); ?>"></script>
        <!-- Barrating -->
        <script src="<?php echo e(asset('frontend/assets/js/jquery.barrating.min.js')); ?>"></script>
        <!-- Jquery-ui -->
        <script src="<?php echo e(asset('frontend/assets/js/jquery-ui.min.js')); ?>"></script>
        <!-- Venobox -->
        <script src="<?php echo e(asset('frontend/assets/js/venobox.min.js')); ?>"></script>
        <!-- Nice Select js -->
        <script src="<?php echo e(asset('frontend/assets/js/jquery.nice-select.min.js')); ?>"></script>
        <!-- ScrollUp js -->
        <script src="<?php echo e(asset('frontend/assets/js/scrollUp.min.js')); ?>"></script>
       
       <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.4/toastr.min.js"></script>
      
        <!-- Main/Activator js -->
        <script src="<?php echo e(asset('frontend/assets/js/main.js')); ?>"></script>

        <script>
            let search = $('#search');
           search.on('keyup', function(){

            let searchvalue = $(this).val();
            let storeData = $('#ul-list');
            let myUrl = "<?php echo e(route('product.search')); ?>"
            setTimeout(() => {
                $.ajax({
                    headers:{
                        'X-CSRF-TOKEN':"<?php echo e(csrf_token()); ?>"
                    },
                    url:myUrl,
                    type:'post',
                    data:{searchVal:searchvalue},
                    dataType:'json',
                    success:(response)=>{
                        console.log(response);
                        let lists = []
                        response.map(result=>{
                            let li = `<li><a class="text-dark" href="/product_show/${result.slug}">${ result.title }</a></li>`
                            lists.push(li);
                            search.val(result.slug);

                        })
                        storeData.html(lists);


                    }
                })
            }, 500);

        })
        </script>
         <script>
            <?php if(Session::has('message')): ?>
            var type = "<?php echo e(Session::get('alert-type','info')); ?>"
            switch(type){
               case 'info':
               toastr.info(" <?php echo e(Session::get('message')); ?> ");
               break;
               case 'success':
               toastr.success(" <?php echo e(Session::get('message')); ?> ");
               break;
               case 'warning':
               toastr.warning(" <?php echo e(Session::get('message')); ?> ");
               break;
               case 'error':
               toastr.error(" <?php echo e(Session::get('message')); ?> ");
               break;
            }
            <?php endif; ?>
           </script>
    </body>

<!-- shopping-cart31:32-->
</html>
<?php /**PATH F:\SUNDISK-PENDRIVE\WDPF-LARAVEL\creative-it-admin-dashboard\resources\views/layouts/frontendapp.blade.php ENDPATH**/ ?>