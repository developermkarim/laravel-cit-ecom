

<?php $__env->startSection('frontend-content'); ?>

<?php
    // print_r($allCarts);
?>

<div class="Shopping-cart-area pt-60 pb-60">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <form action="#">
                    <div class="table-content table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th class="li-product-remove">remove</th>
                                    <th class="li-product-thumbnail">images</th>
                                    <th class="cart-product-name">Product</th>
                                    <th class="li-product-price">Unit Price</th>
                                    <th class="li-product-quantity">Quantity</th>
                                    <th class="li-product-subtotal">Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                   $subToal = 0;
                                  $deliveryCharge=0;   
                                ?>
                               
                              <?php $__currentLoopData = $allCarts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  
                              <?php
                                  $subToal+= $cart->products->price * $cart->quantity;
                                  $deliveryCharge+= $cart->quantity * 50;
                              ?>
                                <tr>
                                    <td ><a href="<?php echo e(route('user.cart.remove',$cart->id)); ?>">❌</a></td>
                                    <td class="li-product-thumbnail"><a href="<?php echo e(url('product_show',$cart->products->slug)); ?>"><img src="<?php echo e($cart->products->thumbnail_uri); ?>" alt="Li's Product Image" width="100" height="100"></a></td>
                                    <td class="li-product-name"><a href="<?php echo e(url('product_show',$cart->products->slug)); ?>"><?php echo e($cart->products->title); ?></a></td>

                                    <td class="li-product-price"><span class="amount"><?php echo e(number_format($cart->products->price,2)); ?>৳</span></td>

                                    <td class="quantity">
                                        <label>Quantity</label>
                                        <div class="cart-plus-minus">
                                            <input class="cart-plus-minus-box" value="<?php echo e($cart->quantity); ?>" type="text">
                                            <div class="dec qtybutton"><i class="fa fa-angle-down"></i></div>
                                            <div class="inc qtybutton"><i class="fa fa-angle-up"></i></div>
                                        <div class="dec qtybutton"><i class="fa fa-angle-down"></i></div><div class="inc qtybutton"><i class="fa fa-angle-up"></i></div></div>
                                    </td>
                                    <td class="product-subtotal"><span class="amount"><?php echo e(number_format($cart->products->price * $cart->quantity,2)); ?>৳</span></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <div class="coupon-all">
                                <div class="coupon">
                                    <input id="coupon_code" class="input-text" name="coupon_code" value="" placeholder="Coupon code" type="text">
                                    <input class="button" name="apply_coupon" value="Apply coupon" type="submit">
                                </div>
                                <div class="coupon2">
                                    

                                    <a href="<?php echo e(route('user.allCart.remove')); ?>">
                                        <input class="button" value="Clear All Cart ✖"></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-5 ml-auto">
                            <div class="cart-page-total">
                                <h2>Cart totals</h2>
                                <ul>
                                    <li>Subtotal <span><?php echo e(number_format($subToal,2)); ?>৳</span></li>
                                    <li>Delivery Charge <span><?php echo e(number_format($deliveryCharge,2)); ?>৳</span></li>
                                    <li>Total <span><?php echo e(number_format($deliveryCharge + $subToal,2)); ?>৳</span></li>
                                </ul>
                                <a href="<?php echo e(url('user/cart/checkout')); ?>">Proceed to checkout</a>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontendapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\CREATIVE-IT-LARAVEL\creative-it-admin-dashboard\resources\views/frontend/cart/cart.blade.php ENDPATH**/ ?>