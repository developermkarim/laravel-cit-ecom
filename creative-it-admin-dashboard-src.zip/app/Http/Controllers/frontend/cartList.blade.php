@extends('layouts.frontendapp')

@section('frontend-content')
    
@endsection